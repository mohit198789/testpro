<?php
if(isset($_POST['send_mail'])) 
{
    
 extract($_POST);

$a=0;
switch ($check_type)
{
    case 'index':
                $ToEmail = 'deminyx.development@gmail.com';

                $EmailSubject = 'index enquiry'; 

                @$mailheader .= "Reply-To: ".@$_POST["your_mail"]."\r\n"; 

                $mailheader .= "Content-type: text/html; charset=iso-8859-1\r\n"; 

                $MESSAGE_BODY = "Name: ".$_POST["your_name"]." "."<br>";

                $MESSAGE_BODY .= "Email: ".$_POST["your_mail"]." "."<br>";



                $MESSAGE_BODY .= "Mob. No.: ".$_POST["your_mob"]." "."<br>";

              

                $MESSAGE_BODY .= "Message: ".nl2br(@$_POST["your_message"])." "; 

                mail($ToEmail, $EmailSubject, $MESSAGE_BODY, $mailheader);
                                 
                    ?>
<script>
alert("mail send");
window.location="index.html";
</script>
<?php
               
                
                break;
            
     case 'contact':
                $ToEmail = 'deminyx.development@gmail.com';

                $EmailSubject = 'contact enquiry'; 

                @$mailheader .= "Reply-To: ".@$_POST["your_mail"]."\r\n"; 

                $mailheader .= "Content-type: text/html; charset=iso-8859-1\r\n"; 

                $MESSAGE_BODY = "Name: ".$_POST["your_name"]." "."<br>";

                $MESSAGE_BODY .= "Email: ".$_POST["your_mail"]." "."<br>";



                $MESSAGE_BODY .= "Mob. No.: ".$_POST["your_mob"]." "."<br>";

              

                $MESSAGE_BODY .= "Message: ".nl2br(@$_POST["your_message"])." "; 

                mail($ToEmail, $EmailSubject, $MESSAGE_BODY, $mailheader);
                                 
                    ?>
<script>
alert("mail send");
window.location="index.html";
</script>
<?php
               
                
                break;
}
}
    ?>